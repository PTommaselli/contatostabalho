let modelContato = new TrataModel();
let controlDados = new ajusteDados(modelContato);
let view = new Recebe(modelContato,controlDados); 
